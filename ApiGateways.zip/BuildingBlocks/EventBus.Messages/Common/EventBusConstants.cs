﻿namespace EventBus.Messages.Common
{
    public static class EventBusConstants
	{
		public const string BasketCheckoutQueue = "basketcheckout-queue";
	}
}
